#include "observer.h"
#include <string>

//class Resource;

Observer::~Observer() {}







