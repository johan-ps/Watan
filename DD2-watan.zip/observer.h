#ifndef OBSERVER_H
#define OBSERVER_H

class Observer {
    public:
    //virtual void notify(int diceVal = 0) = 0;
        virtual ~Observer() = 0;
};

#endif





