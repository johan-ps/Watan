#ifndef OBSERVER_H
#define OBSERVER_H


class Observer {
    public:
       /* virtual void notify() = 0;
        virtual void notify(Resource) = 0;
        virtual void notify(int) = 0;
        virtual void notify(int, char, std::string) = 0;*/
        virtual ~Observer() = 0;
};

#endif





