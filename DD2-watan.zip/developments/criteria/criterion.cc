#include "criterion.h"

Criterion::Criterion(int locationVal, int criteriaVal, std::vector<int> cost):
    Development{locationVal, criteriaVal, cost} {}

Criterion::~Criterion() {}