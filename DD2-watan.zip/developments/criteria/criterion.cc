#include "criterion.h"

Criterion::Criterion(int locationVal, std::vector<int> cost):
    Development{locationVal, cost} {}

Criterion::~Criterion() {}