#include "goal.h"

Goal::Goal(int locationVal, const std::vector<int> cost):
    Development{locationVal, cost} {}

Goal::~Goal() {}




