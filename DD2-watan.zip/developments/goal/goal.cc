#include "goal.h"

Goal::Goal(int locationVal, int criteriaVal, const std::vector<int> cost):
    Development{locationVal, criteriaVal, cost} {}

Goal::~Goal() {}




